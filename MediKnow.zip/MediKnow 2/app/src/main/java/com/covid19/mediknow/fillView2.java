package com.covid19.mediknow;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.cloud.sdk.core.util.GsonSingleton;
import com.ibm.watson.discovery.v1.Discovery;
import com.ibm.watson.discovery.v1.model.Collection;
import com.ibm.watson.discovery.v1.model.CreateEnvironmentOptions;
import com.ibm.watson.discovery.v1.model.Environment;
import com.ibm.watson.discovery.v1.model.ListCollectionsOptions;
import com.ibm.watson.discovery.v1.model.ListCollectionsResponse;
import com.ibm.watson.discovery.v1.model.ListEnvironmentsOptions;
import com.ibm.watson.discovery.v1.model.ListEnvironmentsResponse;
import com.ibm.watson.discovery.v1.model.QueryOptions;
import com.ibm.watson.discovery.v1.model.QueryResponse;
import com.ibm.watson.discovery.v1.model.QueryResult;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class fillView2 extends AsyncTask<Object, Object, Object> {
    Context myCon;
    private String[] t1, p1, s1, u1, d1,h1, k1, ca1,co1,s2;
    String slabel;
    int myCount;
    String myName;
    String matchRes;
    public getData delegate = null;
    int totPos = 0;
    int totNeg =0;
    int totNeut = 0;
    private AlertDialog dialog;
    Class myclass;
    String retActivity;
    String[] mOthers;



    public fillView2(Context c1, int count, String name, String label, Class myClass, String retActivity, String[] other){
        slabel = label;
        myCon = c1;
        myCount = count;
        myName = name;
        myclass = myClass;
        this.retActivity = retActivity;
        mOthers = other;

    }

    public interface getData{
        void DataIsLoaded(Context ct, String matchRes, String[] title, String[] passage, String[] url, String[] sentiment, String[] date, String[] source, String[] keyword, String[] category, String[] concepts, String[] sentiment2, double[] perc);

    }

    @Override
    protected void onPreExecute(){
        AlertDialog.Builder builder = new AlertDialog.Builder(myCon);
        builder.setMessage("Searching...")
                .setCancelable(false);
        dialog = builder.create();
        dialog.show();


    }



    @Override
    protected Object doInBackground(Object... params) {
        //now we are using private dataset


        String[] IDs = {"system", "news-en"};

        IamAuthenticator authenticator = new IamAuthenticator("BlWXIEGNhYSWVu0psGH8P2hGsAFKTfvDThDI95gJKEcP");
        Discovery discovery = new Discovery("2019-04-30", authenticator);
        discovery.setServiceUrl("https://api.us-east.discovery.watson.cloud.ibm.com/instances/82a1c4ed-07e3-4bc0-a7b2-b4aa82a70e1e");

        IDs = getEnvandCollID(discovery, IDs);


        QueryOptions queryOptions = new QueryOptions.Builder(IDs[0], IDs[1])
                .query(myName)
                .count(myCount)
                .build();

        final QueryResponse queryResponse = discovery.query(queryOptions).execute().getResult();
        List<QueryResult> resp = queryResponse.getResults();
        String jsonRes = GsonSingleton.getGson().toJson(resp);
        JsonArray jsonArr = (JsonArray) new JsonParser().parse(jsonRes);

        /**List<QueryPassages> passages = queryResponse.getPassages();
         String jsonpass = GsonSingleton.getGson().toJson(passages);
         JsonElement jsonpassEl = new JsonParser().parse(jsonpass);**/

        t1 = new String[resp.size()];
        p1 = new String[resp.size()];
        s1 = new String[resp.size()];
        s2 = new String[resp.size()];
        h1 = new String[resp.size()];
        co1 = new String[resp.size()];
        k1 = new String[resp.size()];
        ca1 = new String[resp.size()];
        u1 = new String[resp.size()];
        d1 = new String[resp.size()];

        matchRes = String.valueOf(queryResponse.getMatchingResults().intValue());




        if (resp.size() > 0){

            for (int i = 0; i < jsonArr.size(); i++) {

                if (slabel.equalsIgnoreCase("All")) {
                    t1[i] = "";
                    p1[i] = "";
                    d1[i] = "";
                    u1[i] = "";
                    h1[i] = "";

                    t1[i] = jsonArr.get(i).getAsJsonObject().get("title").toString();
                    p1[i] = jsonArr.get(i).getAsJsonObject().get("text").toString();
                    d1[i] = jsonArr.get(i).getAsJsonObject().get("metadata").getAsJsonObject().get("ingest_datetime").toString();
                    u1[i] = jsonArr.get(i).getAsJsonObject().get("metadata").getAsJsonObject().get("source").getAsJsonObject().get("url").getAsString();

                    try {
                        URL myUrl = new URL(u1[i]);
                        String host = myUrl.getHost();
                        h1[i] = host;
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }

                    //enriched text
                    JsonArray coArr = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("concepts").getAsJsonArray();
                    JsonArray caArr = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("categories").getAsJsonArray();
                    JsonArray kArr = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("keywords").getAsJsonArray();
                    JsonObject sObj = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("sentiment").getAsJsonObject();

                    //place in string array
                    co1[i] = "";
                    ca1[i] = "";
                    k1[i] = "";
                    s1[i] = "";
                    s2[i] = "";
                    for (int j = 0; j <coArr.size();j++){
                        if(j == coArr.size()-1){

                            co1[i] = co1[i] + coArr.get(j).getAsJsonObject().get("text").toString();
                        }
                        else {
                            co1[i] = co1[i] + coArr.get(j).getAsJsonObject().get("text").toString() + ", ";
                        }

                    }
                    for (int p = 0; p <caArr.size();p++){
                        if (caArr.get(p).getAsJsonObject().get("text") != null){
                            if(p == caArr.size()-1){

                                ca1[i] = ca1[i] + caArr.get(p).getAsJsonObject().get("text").toString();
                            }
                            else {
                                ca1[i] = ca1[i] + caArr.get(p).getAsJsonObject().get("text").toString() + ", ";
                            }

                        }

                    }
                    for (int q = 0; q <kArr.size();q++){
                        if(q == kArr.size()-1){

                            k1[i] = k1[i] + kArr.get(q).getAsJsonObject().get("text").toString();
                        }
                        else {
                            k1[i] = k1[i] + kArr.get(q).getAsJsonObject().get("text").toString() + ", ";
                        }
                    }

                    s1[i] = sObj.get("document").getAsJsonObject().get("label").toString();


                    s2[i] = sObj.get("document").getAsJsonObject().get("score").toString();


                }

                else{
                    JsonObject sObj = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("sentiment").getAsJsonObject();
                    if (sObj.get("document").getAsJsonObject().get("label").toString().equals("\""+ slabel + "\"")){
                        t1[i] = "";
                        p1[i] = "";
                        d1[i] = "";
                        u1[i] = "";
                        h1[i] = "";

                        t1[i] = jsonArr.get(i).getAsJsonObject().get("title").toString();
                        p1[i] = jsonArr.get(i).getAsJsonObject().get("text").toString();
                        d1[i] = jsonArr.get(i).getAsJsonObject().get("metadata").getAsJsonObject().get("ingest_datetime").toString();
                        u1[i] = jsonArr.get(i).getAsJsonObject().get("metadata").getAsJsonObject().get("source").getAsJsonObject().get("url").toString();

                        try {
                            URL myUrl = new URL(u1[i]);
                            String host = myUrl.getHost();
                            h1[i] = host;
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        //enriched text
                        JsonArray coArr = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("concepts").getAsJsonArray();
                        JsonArray caArr = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("categories").getAsJsonArray();
                        JsonArray kArr = jsonArr.get(i).getAsJsonObject().get("enriched_text").getAsJsonObject().get("keywords").getAsJsonArray();


                        //place in string array
                        co1[i] = "";
                        ca1[i] = "";
                        k1[i] = "";
                        s1[i] = "";
                        s2[i] = "";
                        for (int j = 0; j <coArr.size();j++){
                            if(j == coArr.size()-1){

                                co1[i] = co1[i] + coArr.get(j).getAsJsonObject().get("text").toString();
                            }
                            else {
                                co1[i] = co1[i] + coArr.get(j).getAsJsonObject().get("text").toString() + ", ";
                            }

                        }
                        for (int p = 0; p <caArr.size();p++){
                            if(p == caArr.size()-1){

                                ca1[i] = ca1[i] + caArr.get(p).getAsJsonObject().get("text").toString();
                            }
                            else {
                                ca1[i] = ca1[i] + caArr.get(p).getAsJsonObject().get("text").toString() + ", ";
                            }
                        }
                        for (int q = 0; q <kArr.size();q++){
                            if(q == kArr.size()-1){

                                k1[i] = k1[i] + kArr.get(q).getAsJsonObject().get("text").toString();
                            }
                            else {
                                k1[i] = k1[i] + kArr.get(q).getAsJsonObject().get("text").toString() + ", ";
                            }
                        }

                        s2[i] = sObj.get("document").getAsJsonObject().get("score").toString();

                    }

                }


            }
        }


        String [][] coll = {t1, p1, u1, s1, d1, h1, k1, ca1, co1, s2};
        return coll;
    }

    @Override
    protected void onPostExecute(Object obj) {

        dialog.cancel();
        for (int i = 0; i < s1.length; i++){

            if (s1[i].equalsIgnoreCase("\"positive\"")){
                totPos++;
            }
            else if(s1[i].equalsIgnoreCase("\"negative\"")){


                totNeg++;
            }
            else if(s1[i].equalsIgnoreCase("\"neutral\"")){
                totNeut++;
            }
            else{

                //do nothing
            }

        }


        String convertedToString = String.valueOf(obj);
        double[] perc = {0,0,0};
        if(Integer.parseInt(matchRes) != 0){
            perc = new double[]{(Double.valueOf(totPos) / Double.valueOf(s1.length)) * 100, (Double.valueOf(totNeut) / Double.valueOf(s1.length)) * 100, (Double.valueOf(totNeg) / Double.valueOf(s1.length)) * 100};
        }

        Log.d("Drug2Specific", convertedToString);


        //super.onPostExecute(obj);
        //delegate.DataIsLoaded(myCon,matchRes,t1, p1, u1, s1, d1, h1, k1, ca1, co1, s2, perc);

        Intent intent = new Intent(myCon,myclass);
        intent.putExtra("count",Integer.parseInt(matchRes));
        intent.putExtra("title",t1);
        intent.putExtra("passage",p1);
        intent.putExtra("url",u1);
        intent.putExtra("sentiment label",s1);
        intent.putExtra("date",d1);
        intent.putExtra("source",h1);
        intent.putExtra("keywords",k1);
        intent.putExtra("category",ca1);
        intent.putExtra("concepts",co1);
        intent.putExtra("sentiment score",s2);
        intent.putExtra("percentages",perc);
        intent.putExtra("Ret Activity",retActivity);
        intent.putExtra("Query Count", myCount);
        intent.putExtra("Query sentiment", slabel);
        intent.putExtra("Name",myName);
        intent.putExtra("Other Searches",mOthers);
        ((Activity)myCon).startActivity(intent);
    }







    public String[] getEnvandCollID(Discovery discovery, String[] IDs){
        //searching up for existing environments
        ListEnvironmentsOptions options = new ListEnvironmentsOptions.Builder().build();
        ListEnvironmentsResponse listResponse = discovery.listEnvironments(options).execute().getResult();
        List<Environment> environments = listResponse.getEnvironments();
        if (environments.size() != 0) {

            IDs[0] = environments.get(1).getEnvironmentId().toString();
        }
        else{
            //creating a new environment
            String environmentName = "my_environment";
            String environmentDesc = "My environment";

            CreateEnvironmentOptions.Builder createOptionsBuilder = new CreateEnvironmentOptions.Builder(environmentName);
            createOptionsBuilder.description(environmentDesc);
            Environment createResponse = discovery.createEnvironment(createOptionsBuilder.build()).execute().getResult();
            IDs[0] = createResponse.getEnvironmentId();
        }

        ListCollectionsOptions listOptions = new ListCollectionsOptions.Builder(IDs[0]).build();
        ListCollectionsResponse listResponse2 = discovery.listCollections(listOptions).execute().getResult();
        List<Collection> collections = listResponse2.getCollections();
        //searching for my collection
        for (Collection coll:collections){
            if (coll.getName().equalsIgnoreCase("COVID-19 Content 04-27-2020 3:11:34 AM")){
                IDs[1] = collections.get(0).getCollectionId();
            }

        }

        return IDs;

    }

}