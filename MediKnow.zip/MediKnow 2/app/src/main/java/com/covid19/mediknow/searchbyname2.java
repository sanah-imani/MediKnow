package com.covid19.mediknow;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.PieData;

import java.util.ArrayList;
import java.util.List;

public class searchbyname2 extends AppCompatActivity {

    RecyclerView recyclerView;
    String name;
    Toolbar toolbar;
    Spinner spin1;
    Spinner spin2;
    TextView matchRes;
    String matchResCount;
    PieChart chart1;
    String[] t1, p1, s1, u1, d1,h1, k1, ca1,co1,s2;
    String[] valspin1 = {"10", "15", "20"};
    String[] valspin2 = {"All","Positive", "Neutral", "Negative"};
    String[] sent = {"Positive", "Neutral", "Negative"};
    double[] perc = {0 ,0 , 0};
    int count = 10;
    String slabel = "All";
    Button b1;
    int check1 = 0;
    int check2 = 0;
    TextView other;
    String[] arrOthers;
    //for the first spinner
    ArrayAdapter<String> dataAdapter;
    ArrayAdapter<String> dataAdapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchbyname2);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        spin1 = (Spinner) findViewById(R.id.Spin1);
        spin2 = (Spinner) findViewById(R.id.Spin2);
        recyclerView = (RecyclerView) findViewById(R.id.recview1);
        matchRes = (TextView)findViewById(R.id.matchResults);
        chart1 = (PieChart) findViewById(R.id.chartview);
        b1 = findViewById(R.id.searchArt);
        other = findViewById(R.id.other);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            name =  bundle.getString("Name");
            arrOthers = bundle.getStringArray("Other Searches");
            //setSupportActionBar(toolbar);
            //getSupportActionBar().setTitle(name);
        }
        getData();

        if(arrOthers.length>0){
            other.setVisibility(View.VISIBLE);
            searchOtherAdapter sa = new searchOtherAdapter(searchbyname2.this,arrOthers,name,count,slabel,searchAnalytics.class,"Vaccine");
            recyclerView.setAdapter(sa);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }
        else{
            other.setVisibility(View.GONE);
        }


        dataAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,valspin1);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin1.setAdapter(dataAdapter);
        for(int i =0; i <valspin1.length; i++){
            if(Integer.parseInt(valspin1[i]) == count){
                spin1.setSelection(i,true);
            }
        }
        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                check1++;
                if (check1 > 1) {
                    if (valspin1[position].equalsIgnoreCase("10")){
                        count =10;
                        getFillView();

                    }
                    else if(valspin1[position].equalsIgnoreCase("15")){
                        count = 15;
                        getFillView();
                    }
                    else{
                        count = 20;
                        getFillView();
                    }

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                getFillView();
            }
        });
        //for the second spinner

        dataAdapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item,valspin2);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin2.setAdapter(dataAdapter2);
        for(int i =0; i <valspin2.length; i++){
            if(valspin2[i] == slabel){
                spin2.setSelection(i,true);
            }
        }
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                check2++;
                if(check2>1){
                    if (valspin2[position].equalsIgnoreCase("All")){
                        slabel = "All";
                        getFillView();

                    }
                    else if(valspin2[position].equalsIgnoreCase("Positive")){
                        slabel = "Positive";
                        getFillView();
                    }
                    else if (valspin2[position].equalsIgnoreCase("Neutral")){
                        slabel = "Neutral";
                        getFillView();
                    }
                    else{
                        slabel = "Negative";
                        getFillView();
                    }

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                getFillView();
            }
        });




        matchRes.setText("Matching results: " + matchResCount);

        PieData data1 = new chartDraw(this).setUpPieMPChart(sent, perc,"Sleep Quality Percentages");
        if (data1 == null || data1.getEntryCount() == 0){
            Toast.makeText(this, "No sentiment pie chart could be generated", Toast.LENGTH_SHORT).show();
        }
        else{
            data1.setValueTextSize(13f);
            data1.setValueTextColor(Color.WHITE);
            chart1.clear();
            chart1.getLegend().setTextColor(Color.BLACK);
            chart1.getDescription().setText("");
            LegendEntry[] legendEntries = chart1.getLegend().getEntries();
            for(int j = 0; j < legendEntries.length; j++){
                if(legendEntries[j].label.equals("")){

                    legendEntries[j].label = sent[j];
                }
            }
            chart1.getLegend().setCustom(legendEntries);
            chart1.setUsePercentValues(true);
            chart1.setDrawHoleEnabled(false);
            chart1.setData(data1);
            chart1.invalidate();

        }


        if(matchResCount != null) {
            if (Integer.parseInt(matchResCount) == 0) {
                b1.setEnabled(false);
                Toast.makeText(searchbyname2.this,"No results",Toast.LENGTH_LONG).show();
            }
        }

        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(searchbyname2.this, searchAnalytics.class);
                if (Integer.parseInt(matchResCount) < count){
                    intent.putExtra("count", Integer.parseInt(matchResCount));
                }
                else{
                    intent.putExtra("count", count);
                }
                intent.putExtra("title", t1);
                intent.putExtra("passage", p1);
                intent.putExtra("date", d1);
                intent.putExtra("source", h1);
                intent.putExtra("sentiment score", s2);
                intent.putExtra("sentiment label", s1);
                intent.putExtra("keywords", k1);
                intent.putExtra("category", ca1);
                intent.putExtra("concepts", co1);
                intent.putExtra("url", u1);
                intent.putExtra("Ret Activity", "Drug2");
                startActivity(intent);
            }
        });


    }

    private void getData(){
        if(getIntent().hasExtra("count")){
            matchResCount = String.valueOf(getIntent().getIntExtra("count",0));
        }

        if(getIntent().hasExtra("title")){
            t1 = getIntent().getStringArrayExtra("title");
        }
        if(getIntent().hasExtra("passage")){

            p1 = getIntent().getStringArrayExtra("passage");


        }
        if(getIntent().hasExtra("date")){
            d1 = getIntent().getStringArrayExtra("date");

        }
        if(getIntent().hasExtra("source")){

            h1 = getIntent().getStringArrayExtra("source");

        }
        if(getIntent().hasExtra("sentiment score")){

            s2 = getIntent().getStringArrayExtra("sentiment score");

        }
        if(getIntent().hasExtra("sentiment label")){

            s1 =  getIntent().getStringArrayExtra("sentiment label");

        }
        if(getIntent().hasExtra("keywords")){

            k1 = getIntent().getStringArrayExtra("keywords");

        }
        if(getIntent().hasExtra("category")){

            ca1 = getIntent().getStringArrayExtra("category");

        }
        if(getIntent().hasExtra("concepts")){

            co1 = getIntent().getStringArrayExtra("concepts");

        }

        if(getIntent().hasExtra("url")){

            u1 = getIntent().getStringArrayExtra("url");

        }
        if(getIntent().hasExtra("percentages")){
            perc = getIntent().getDoubleArrayExtra("percentages");

        }
        if(getIntent().hasExtra("Query Sentiment")){
            slabel = getIntent().getStringExtra("Query Sentiment");
        }
        if(getIntent().hasExtra("Query Count")){
            count = getIntent().getIntExtra("Query Count",10);
        }


    }


    public void getFillView(){
        fillView2 f1 = new fillView2(searchbyname2.this, count, name, slabel,searchbyname3.class, "Drug2",arrOthers);
//
        f1.execute();

    }

}
