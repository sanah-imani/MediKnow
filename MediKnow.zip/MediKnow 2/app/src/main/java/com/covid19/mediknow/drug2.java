package com.covid19.mediknow;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class drug2 extends AppCompatActivity {
    List<List<String>> mdata;
    List<String> mkeys;
    SearchView mySearchView;
    ListView myListView;
    ArrayList<String> list;
    ArrayAdapter adapter;
    Toolbar toolbar;
    Spinner spinner,spinner2;
    String[] spinnerValue = {"All categories","corticosteroid", "NSAID", "analgesic", "antipyretic", "anti-inflammatory", "immunosuppressant", "protein-therapy"};
    String[] proteins = {"enzyme","peptide","antibody","amino acid","protein","peptides", "enzymes", "antibodies", "amino acids", "proteins"};
    String[] spinnerValue2 = {"All","Approved","Investigational", "Experimental"};
    ArrayAdapter<String> dataAdapter,dataAdapter2;
    private AlertDialog dialog;
    int check = 0;
    int check2 = 0;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drug2);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        mySearchView = (SearchView) findViewById(R.id.searchView);
        myListView = (ListView) findViewById(R.id.listView);
        spinner = (Spinner) findViewById(R.id.Spin1);
        spinner2 = findViewById(R.id.Spin2);
        list = new ArrayList<String>();
        //mdata = new readCSV(drug2.this, "otcdrugs").readRecord();
        AlertDialog.Builder builder = new AlertDialog.Builder(drug2.this);
        builder.setMessage("Searching...")
                .setCancelable(false);
        dialog = builder.create();
        dialog.show();
        new FirebaseDatabaseHelper(drug2.this,"masterSheet3").readRecord(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<List<String>> data, List<String> keys) {
                mdata = data;
                mkeys = keys;
            }

            @Override
            public void DataIsQueryed(List<List<String>> data, List<String> keys) {

            }
        });
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateList();
                dialog.cancel();
                checkErrors();
            }
        }, 5000);


        dataAdapter = new ArrayAdapter(drug2.this, android.R.layout.simple_spinner_item,spinnerValue);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        dataAdapter2 = new ArrayAdapter(drug2.this, android.R.layout.simple_spinner_item,spinnerValue2);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter2);
        mySearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                adapter.notifyDataSetChanged();
                if(adapter.getCount() == 0){
                    Toast.makeText(getApplicationContext(), "No matches", Toast.LENGTH_SHORT).show();
                }
                return false;

            }
        });
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(drug2.this, drug2specifics.class);
                intent.putExtra("Drug2 Name", myListView.getItemAtPosition(position).toString());
                int reqPos = 0;
                for(int i = 0; i < mdata.size(); i++){
                    if(mdata.get(i).get(0).equalsIgnoreCase(myListView.getItemAtPosition(position).toString())){
                        reqPos = i;
                    }
                }
                String[] arrayData = new String[mdata.get(reqPos).size()];
                for (int i = 0; i < arrayData.length; i++){
                    arrayData[i] = mdata.get(reqPos).get(i);
                }
                intent.putExtra("Drug2 Details", arrayData);
                startActivity(intent);
            }
        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(parent.getContext(), "Selected " + parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
                if(check > 0){
                    list.clear();
                    adapter.clear();

                    String otherItem = spinnerValue2[spinner2.getSelectedItemPosition()].toLowerCase();
                    int otherPos = spinner2.getSelectedItemPosition();

                    if (mdata != null) {
                        for (List<String> l1 : mdata) {
                            if (l1 != null) {
                                if(otherPos == 0){
                                    list.add(l1.get(0));
                                }

                                else{
                                    if(l1.get(6).toLowerCase().contains(otherItem)){
                                        list.add(l1.get(0));

                                    }
                                }


                            }
                        }
                    }

                    List<String> copiedList = new ArrayList<>(list);
                    list.clear();

                    if (mdata != null) {
                        for(List<String> l1: mdata){
                            if(l1 != null) {

                                if(position != 1 && position != 0 && position != spinnerValue.length-1) {
                                    if ((l1.get(2).toLowerCase().indexOf(spinnerValue[position].toLowerCase()) != -1) || (l1.get(3).toLowerCase().indexOf(spinnerValue[position].toLowerCase()) != -1)) {
                                        if(copiedList.contains(l1.get(0))){
                                            list.add(l1.get(0));
                                        }

                                    }
                                }
                                else if(position == spinnerValue.length-1){
                                    for (String prot:proteins){
                                        if(l1.get(2).toLowerCase().contains(prot)){
                                            if(copiedList.contains(l1.get(0))){
                                                list.add(l1.get(0));
                                            }
                                        }
                                    }
                                }
                                else if (position == 0){
                                    if(copiedList.contains(l1.get(0))){
                                        list.add(l1.get(0));
                                    }

                                }
                                else{
                                    if(((l1.get(2).toLowerCase().indexOf(spinnerValue[position].toString().toLowerCase()) != -1) || (l1.get(2).toLowerCase().indexOf("glucocorticoid") != -1)) || (l1.get(2).toLowerCase().indexOf("mineralocorticoid") != -1)){
                                        if(copiedList.contains(l1.get(0))){
                                            list.add(l1.get(0));
                                        }
                                    }


                                }
                            }
                        }
                    }

                    adapter.notifyDataSetChanged();
                    if(adapter.getCount() == 0){
                        Toast.makeText(getApplicationContext(), "No matches", Toast.LENGTH_SHORT).show();
                    }

                }

                check++;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(parent.getContext(), "Selected " + parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
                if(check2>0){
                    list.clear();
                    adapter.clear();

                    String otherItem = spinnerValue[spinner.getSelectedItemPosition()].toLowerCase();
                    int otherPos = spinner.getSelectedItemPosition();
                    if (mdata != null) {
                        for(List<String> l1: mdata){
                            if(l1 != null) {

                                if(otherPos != 1 && otherPos != 0 && otherPos != spinnerValue2.length-1) {
                                    if ((l1.get(2).toLowerCase().indexOf(otherItem) != -1) || (l1.get(3).toLowerCase().indexOf(otherItem) != -1)) {
                                        list.add(l1.get(0));
                                    }
                                }
                                else if(otherPos == spinnerValue2.length-1){
                                    for (String prot:proteins){
                                        if(l1.get(2).toLowerCase().contains(prot)){
                                            list.add(l1.get(0));
                                        }
                                    }
                                }
                                else if (otherPos == 0){
                                    list.add(l1.get(0));

                                }
                                else{
                                    if(((l1.get(2).toLowerCase().indexOf(otherItem) != -1) || (l1.get(2).toLowerCase().indexOf("glucocorticoid") != -1)) || (l1.get(2).toLowerCase().indexOf("mineralocorticoid") != -1)){
                                        list.add(l1.get(0));
                                    }


                                }
                            }
                        }
                    }

                    List<String> copiedList = new ArrayList<>(list);
                    list.clear();

                    if (mdata != null) {
                        for (List<String> l1 : mdata) {
                            if (l1 != null) {
                                if(position == 0){
                                    if(copiedList.contains(l1.get(0))){
                                        list.add(l1.get(0));
                                    }
                                }
                                else{
                                    if(l1.get(6).toLowerCase().contains(spinnerValue2[position].toLowerCase())){
                                        if(copiedList.contains(l1.get(0))){
                                            list.add(l1.get(0));
                                        }

                                    }
                                }


                            }
                        }
                    }
                    adapter.notifyDataSetChanged();
                    if(adapter.getCount() == 0){
                        Toast.makeText(getApplicationContext(), "No matches", Toast.LENGTH_SHORT).show();
                    }
                }
                check2++;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void updateList(){
        list.clear();
        if (mdata != null) {
            for (List<String> l1 : mdata) {
                if (l1 != null) {
                    list.add(l1.get(0));

                }
            }
        }
        adapter = new ArrayAdapter<>(drug2.this, android.R.layout.simple_list_item_1, list);
        myListView.setAdapter(adapter);

    }

    public void retHome(View view) {
        startActivity(new Intent(drug2.this,MainActivity.class));
    }

    public void checkErrors(){
        if(list.size() == 0){
            if(!vaccine.isNetworkAvailable(this)){
                AlertDialog.Builder builder = new AlertDialog.Builder(drug2.this);
                builder.setMessage("No network connection")
                        .setCancelable(false)
                        .setPositiveButton("OK",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                Intent intent =  new Intent(drug2.this,MainActivity.class);
                                startActivity(intent);

                            }
                        });

                dialog = builder.create();
                dialog.show();

            }
            else{
                AlertDialog.Builder builder = new AlertDialog.Builder(drug2.this);
                builder.setMessage("Seems like the app needs to be updated..")
                        .setCancelable(false)
                        .setPositiveButton("Visit Website",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                Intent intent =  new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.sanahimani.com/mediknow"));
                                startActivity(intent);

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                dialog = builder.create();
                dialog.show();
            }

        }
    }
}
