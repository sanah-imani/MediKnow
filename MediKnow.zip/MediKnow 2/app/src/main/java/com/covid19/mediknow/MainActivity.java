package com.covid19.mediknow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private CardView drugCard, vaccineCard;
    List<List<String>> mdata;
    List<String> mkeys;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drugCard = (CardView) findViewById(R.id.drug);
        vaccineCard = (CardView) findViewById(R.id.vaccine);
        drugCard.setOnClickListener(this);
        vaccineCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;
        switch (v.getId()) {
            case R.id.drug:
                i = new Intent(this, MainActivityDrugSplit.class);
                startActivity(i);
                break;
            case R.id.vaccine:
                i = new Intent(this, vaccine.class);
                startActivity(i);
                break;
            default:
                break;


        }
    }

    public void readText(){
        new FirebaseDatabaseHelper(this, "masterSheet").readRecord(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<List<String>> data, List<String> keys) {
                mdata = new ArrayList<>();
                mdata = data;
                mkeys = new ArrayList<>();
                mkeys = keys;


            }

            @Override
            public void DataIsQueryed(List<List<String>> data, List<String> keys) {

            }
        });

    }
}
