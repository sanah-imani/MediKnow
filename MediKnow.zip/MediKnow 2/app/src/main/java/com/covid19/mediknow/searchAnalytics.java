package com.covid19.mediknow;

import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.commons.lang3.StringUtils;

public class searchAnalytics extends AppCompatActivity {

    TextView host, date, title, passage, sentiment, concepts, categories, keywords, url;

    String Shost, Sdate, Stitle, Spassage, Ssentiment, Sconcepts, Scategories, Skeywords, Surl;

    int qNum;

    int count;

    Button b1, b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchbyname_analytics);

        host = (TextView) findViewById(R.id.host);
        date = (TextView) findViewById(R.id.date);
        title = (TextView) findViewById(R.id.title);
        passage = (TextView) findViewById(R.id.fullpassage);
        sentiment = (TextView) findViewById(R.id.sentiment1);
        concepts = (TextView) findViewById(R.id.concepts);
        categories = (TextView) findViewById(R.id.category);
        keywords = findViewById(R.id.keywords);
        url = findViewById(R.id.url);
        b1 = findViewById(R.id.back);
        b2 = findViewById(R.id.next);
        qNum = 0;

        b1.setEnabled(false);

        getData();
        setData();


        while(Stitle == null){
            //do nothing
        }

        if(getIntent().hasExtra("count")){
            count = getIntent().getIntExtra("count",10);
        }
        url.setPaintFlags(url.getPaintFlags() |   Paint.UNDERLINE_TEXT_FLAG);
        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connect1();
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qNum--;
                if (qNum == 0){
                    b1.setEnabled(false);
                    getData();
                    setData();
                }
                else{
                    getData();
                    setData();
                }

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qNum++;
                if (qNum > 0 && (qNum + 1)<=count){
                    b1.setEnabled(true);
                    getData();
                    setData();
                    if((qNum + 1)<=count){
                        b2.setText("Return");
                    }

                }
                else{
                    endSearch();
                }

            }
        });



    }

    private void getData(){
        Ssentiment = "";
        if(getIntent().hasExtra("title")){
            Stitle = removeNewLine(getIntent().getStringArrayExtra("title")[qNum]);
        }
        if(getIntent().hasExtra("passage")){

            Spassage = getIntent().getStringArrayExtra("passage")[qNum];


        }
        if(getIntent().hasExtra("date")){
            Sdate = getIntent().getStringArrayExtra("date")[qNum];

        }
        if(getIntent().hasExtra("source")){

            Shost = getIntent().getStringArrayExtra("source")[qNum];

        }
        if(getIntent().hasExtra("sentiment score")){

            Ssentiment = getIntent().getStringArrayExtra("sentiment score")[qNum];

        }
        if(getIntent().hasExtra("sentiment label")){

            Ssentiment = Ssentiment + " (" + getIntent().getStringArrayExtra("sentiment label")[qNum] + ")";

        }
        if(getIntent().hasExtra("keywords")){

            Skeywords = getIntent().getStringArrayExtra("keywords")[qNum];

        }
        if(getIntent().hasExtra("category")){

            Scategories = getIntent().getStringArrayExtra("category")[qNum];

        }
        if(getIntent().hasExtra("concepts")){

            Sconcepts = getIntent().getStringArrayExtra("concepts")[qNum];

        }

        if(getIntent().hasExtra("url")){

            Surl = getIntent().getStringArrayExtra("url")[qNum];

        }


    }

    private void setData(){
        if (!Stitle.equals("")){
            title.setText("Title: " + Stitle);
        }
        else{
            title.setText("Title: No data");
        }

        if (!Spassage.equals("")){
            passage.setText(Spassage);
        }
        else{
            passage.setText("Extracted Passage: No data");
        }

        if (!host.equals("")){
            host.setText("Source: " + Shost);
        }
        else{
            host.setText("Source: No data");
        }

        if (!Sdate.equals("")){
            date.setText("Publication Date: " + Sdate);
        }
        else{
            date.setText("Publication Date: No data");
        }

        if (!Ssentiment.equals("")){
            sentiment.setText("Sentiment Score (Label): " + Ssentiment);
        }
        else{
            sentiment.setText("Sentiment Score (Label): No data");
        }

        if (!Skeywords.equals("")){
            keywords.setText("Keywords: " + Skeywords);
        }
        else{
            keywords.setText("Keywords: No data");
        }

        if (!Scategories.equals("")){
            categories.setText("Categories: " + Scategories);
        }
        else{
            categories.setText("Categories: No data");
        }

        if (!Sconcepts.equals("")){
            concepts.setText("Concepts: " + Sconcepts);
        }
        else{
            concepts.setText("Concepts: No data");
        }

    }

    public void connect1(){


        Intent intent =  new Intent(Intent.ACTION_VIEW, Uri.parse(Surl));
        startActivity(intent);
    }

    public void endSearch(){
        Intent intent = null;
        if (getIntent().hasExtra("Ret Activity")){
            if(getIntent().getStringExtra("Ret Activity").equals("Vaccine")){
                intent =  new Intent(searchAnalytics.this, vaccine.class);
            }
            else if(getIntent().getStringExtra("Ret Activity").equals("Drug")){
                intent =  new Intent(searchAnalytics.this, drug.class);
            }
            else{
                intent =  new Intent(searchAnalytics.this, drug2.class);

            }
        }
        if (intent != null){
            startActivity(intent);
        }

    }

    public String removeNewLine(String line){
        String retString = line.replaceAll("\"", "");
        String retStringChomped = StringUtils.chomp(retString);
        return retStringChomped;


    }
}
