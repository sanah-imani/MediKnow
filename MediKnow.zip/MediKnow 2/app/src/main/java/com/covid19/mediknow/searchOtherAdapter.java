package com.covid19.mediknow;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class searchOtherAdapter extends RecyclerView.Adapter<searchOtherAdapter.ViewHolder> {
    private List<String> mTerms;
    private String[] origTerms;
    private Context c1;
    private int mcount;
    private String mslabel;
    private Class myClass;
    private String mretAct;
    private String mSearch;

    public searchOtherAdapter(Context c, String[] terms, String currSearch, int count, String slabel, Class sClass, String retAct){
        c1 = c;
        origTerms = terms;
        mTerms = new ArrayList<>();
        for (int i =0; i <terms.length;i++){
            if(!terms[i].equals(currSearch)){
                mTerms.add(terms[i]);
            }

        }
        mSearch = currSearch;
        mcount = count;
        mslabel = slabel;
        myClass = sClass;
        mretAct = retAct;

    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(c1);
        View view = inflater.inflate(R.layout.my_row,parent,false);
        return new searchOtherAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.alternatives.setText(mTerms.get(position));
        holder.alternatives.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fillView2 f1 = new fillView2(c1, mcount, mTerms.get(position), mslabel,c1.getClass(), mretAct,origTerms);
//
                f1.execute();
            }
        });


    }

    @Override
    public int getItemCount() {
        return mTerms.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView alternatives;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            alternatives = itemView.findViewById(R.id.term);
        }
    }
}
