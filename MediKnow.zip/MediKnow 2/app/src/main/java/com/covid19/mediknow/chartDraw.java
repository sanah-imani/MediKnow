package com.covid19.mediknow;

import android.content.Context;
import android.graphics.Color;

import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class chartDraw {
    Context myCon;

    public chartDraw(Context c1){

        myCon = c1;

    }

    public PieData setUpPieMPChart(String[] labels, double[] percentages, String label){
        ArrayList<PieEntry> yvalues = new ArrayList<>();
        int countZeroes = 0;
        for(int i = 0; i <percentages.length;i++){
            if(percentages[i] == 0){
                countZeroes++;
            }
        }
        if(countZeroes == 3){
            return null;
        }
        for(int i = 0; i < percentages.length; i++){
            if(percentages.length == labels.length){
                if(percentages[i] <= 10){
                    if(percentages[i] == 0){
                        //do nothing
                    }
                    else{
                        yvalues.add(new PieEntry((float) percentages[i], labels[i]));
                    }


                }
                else{
                    yvalues.add(new PieEntry((float) percentages[i], labels[i]));
                }

            }
        }

        PieData data = new PieData();

        if(yvalues != null){
            PieDataSet dataSet = new PieDataSet(yvalues, label);
            dataSet.setValueTextColor(Color.WHITE);
            data.setDataSet(dataSet);

            data.setValueFormatter(new PercentFormatter());

            dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        }

        return data;

    }
}
