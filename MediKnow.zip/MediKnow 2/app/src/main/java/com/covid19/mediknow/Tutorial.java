package com.covid19.mediknow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;

public class Tutorial extends AppCompatActivity {
    ViewPager viewPager;
    DotsIndicator dots1;
    ViewAdapter viewAdapter;
    Button btn;
    CheckBox ch1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutorial);
        viewPager = findViewById(R.id.view_pager);
        dots1 = findViewById(R.id.dot1);
        btn = findViewById(R.id.btn);
        ch1 = findViewById(R.id.ensure);

        viewAdapter = new ViewAdapter(this,btn);
        viewPager.setAdapter(viewAdapter);
        dots1.setViewPager(viewPager);



    }

    public void switchToMain(View view) {
        if(!ch1.isChecked()){
            Toast.makeText(this,"Please check the box above", Toast.LENGTH_LONG).show();
        }
        else{
            Intent i = new Intent(Tutorial.this,MainActivity.class);
            startActivity(i);
        }

    }

    public void switchToDisc(View view) {
        Intent i = new Intent(Tutorial.this,Disclaimer.class);
        startActivity(i);
    }
}
