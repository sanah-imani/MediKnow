package com.covid19.mediknow;


import androidx.multidex.MultiDexApplication;

public class App extends MultiDexApplication {
}
