package com.covid19.mediknow;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseDatabaseHelper {


    private FirebaseDatabase fire;
    private DatabaseReference mRef2;
    private List<List<String>> data = new ArrayList<List<String>>();

    Context myCon;
    public FirebaseDatabaseHelper(Context c1, String dName){
        myCon = c1;
        fire = FirebaseDatabase.getInstance();
        mRef2 = fire.getReference().child(dName);

    }

    public interface DataStatus{
        void DataIsLoaded(List<List<String>> data, List<String> keys);
        void DataIsQueryed(List<List<String>> data, List<String> keys);

    }


    public void readRecord(final DataStatus dataStatus) {

        mRef2.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data.clear();
                List<String> keys = new ArrayList<>();

                for (DataSnapshot keyNode : dataSnapshot.getChildren()) {

                    keys.add(keyNode.getKey());
                }
                for (DataSnapshot keyNode : dataSnapshot.getChildren()) {
                    ArrayList<String> singRec = new ArrayList<>();
                    for (DataSnapshot childKeyNode : keyNode.getChildren()) {
                        singRec.add(childKeyNode.getValue(String.class));
                    }
                    data.add(singRec);
                }

                dataStatus.DataIsLoaded(data, keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void queryReadRecord(final DataStatus dataStatus, String listItem, Query query){
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data.clear();
                List<String> keys = new ArrayList<>();

                for (DataSnapshot keyNode: dataSnapshot.getChildren()){
                    keys.add(keyNode.getKey());
                }
                for (DataSnapshot keyNode: dataSnapshot.getChildren()){
                    ArrayList<String> singRec = new ArrayList<>();
                    for (int i = 0; i <keys.size();i++){
                        singRec.add(keyNode.child(keys.get(i)).getValue(String.class));
                    }
                    data.add(singRec);
                }

                dataStatus.DataIsQueryed(data,keys);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                Toast.makeText(myCon, "Error", Toast.LENGTH_SHORT).show();

            }
        });
    }

}
