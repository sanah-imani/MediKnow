package com.covid19.mediknow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivityDrugSplit extends AppCompatActivity implements View.OnClickListener{

    private CardView drug1Card, drug2card;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_drug_split);
        drug1Card = (CardView) findViewById(R.id.drug1);
        drug2card = (CardView) findViewById(R.id.drug2);
        drug1Card.setOnClickListener(this);
        drug2card.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;
        switch (v.getId()){
            case R.id.drug1: i = new Intent(this, drug2.class); startActivity(i);break;
            case R.id.drug2: i = new Intent(this, drug.class); startActivity(i); break;
            default: break;

        }
    }
}
