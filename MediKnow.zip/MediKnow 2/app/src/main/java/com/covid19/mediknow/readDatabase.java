package com.covid19.mediknow;

import android.content.Context;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

public class readDatabase extends AsyncTask<Void,Void,Void> {
    public List<List<String>> mdata;
    public List<String> mkeys;
    Context myCon;
    String myName;
    public readDatabase(Context c1,String dName, postData pd){
        myCon = c1;
        myName = dName;
    }

    final postData pd = null;

    public interface postData{
        void onDataChange(List<List<String>> data);
    }

    @Override
    protected Void doInBackground(Void... voids) {

        new FirebaseDatabaseHelper(myCon, myName).readRecord(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<List<String>> data, List<String> keys) {
                mdata = new ArrayList<>();
                mdata = data;
                mkeys = new ArrayList<>();
                mkeys = keys;
            }

            @Override
            public void DataIsQueryed(List<List<String>> data, List<String> keys) {

            }
        });
        return null;
    }
    @Override
    protected void onPostExecute(Void result){
        super.onPostExecute(result);
        pd.onDataChange(mdata);


    }
}
