package com.covid19.mediknow;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class readCSV {

    List<List<String>> mdata;
    String myPath;
    Context myCon;

    public readCSV(Context c1, String path){
        myPath = path;
        myCon = c1;
    }


    public List<List<String>> readRecord(){
        InputStream is = null;
        mdata = new ArrayList<>();
        if (myPath.equalsIgnoreCase("vaccine_candidates")){
            is = myCon.getResources().openRawResource(R.raw.vaccine_candidates);
        }
        else if ((myPath.equalsIgnoreCase("drug_candidates"))){
            is = myCon.getResources().openRawResource(R.raw.drug_candidates);

        }
        else if((myPath.equalsIgnoreCase("otcdrugs"))){
            is = myCon.getResources().openRawResource(R.raw.otcdrugs);

        }
        else if(myPath.equalsIgnoreCase("q_list")){
            is = myCon.getResources().openRawResource(R.raw.q_list);

        }
        else {
            Toast.makeText(myCon, "Wrong file accessed", Toast.LENGTH_LONG).show();

        }

        if (is != null){
            final BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String line = "";

            try {

                while ((line = br.readLine()) != null) {
                    String[] tokens = line.split((",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"));
                    for (int i = 0; i < tokens.length; i++) {
                        tokens[i] = tokens[i].replaceAll("\"", "");
                    }

                    List<String> singRec = new ArrayList<>();

                    for (int i = 0; i < (tokens.length); i++){
                        singRec.add(i,tokens[i]);

                    }
                    mdata.add(singRec);

                }
            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }

        }

        return mdata;
    }







}
