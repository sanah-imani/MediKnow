package com.covid19.mediknow;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class drugSpecifics extends AppCompatActivity {
    String myName;
    String myMOA;

    TextView name;
    TextView type;
    TextView indication;
    TextView approval;
    TextView target;
    TextView moa;
    TextView desc;
    String rawlink;
    Button link;
    Button search1;
    Button search2;
    Button covid_status;
    List<String> options;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drug_specifics);
        name = (TextView) findViewById(R.id.name);
        type = (TextView) findViewById(R.id.type);
        indication = (TextView) findViewById(R.id.indication);
        approval = (TextView) findViewById(R.id.approval);
        target = (TextView) findViewById(R.id.target);
        moa = (TextView) findViewById(R.id.moa);
        link = (Button) findViewById(R.id.link);
        search1 = (Button) findViewById(R.id.search1);
        search2 = (Button) findViewById(R.id.search2);
        covid_status = findViewById(R.id.covid_status);
        desc = findViewById(R.id.description);
        desc.setVisibility(View.GONE);
        rawlink = "";
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            name.setText("Name: " + bundle.getString("Drug Name"));
            myName = bundle.getString("Drug Name");
            if(bundle.getString("Drug Name").equals("No name")){
                myName = "-";
            }
            fillRest();

        }
        covid_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(covid_status.getText().toString().equals("COVID-19 Status")){
                    desc.setVisibility(View.VISIBLE);
                    covid_status.setText("Hide");
                }
                else{
                    desc.setVisibility(View.GONE);
                    covid_status.setText("COVID-19 Status");
                }

            }
        });
        search1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "Searching by Name..", Toast.LENGTH_SHORT).show();
                //openSearchbyName();
                if(isNetworkAvailable(drugSpecifics.this)){
                    if(myName != null && !myName.equals("-")){
                        options = getSearchTerms(myName);
                        getFillView(options.get(0));
                    }
                    else{
                        Toast.makeText(drugSpecifics.this, "Invalid search", Toast.LENGTH_LONG).show();
                    }

                }
                else{
                    Toast.makeText(drugSpecifics.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                }

            }
        });
        search2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "Searching by MOA..", Toast.LENGTH_SHORT).show();
                //openSearchbyMOA();
                if(isNetworkAvailable(drugSpecifics.this)){
                    if(myMOA != null && !myMOA.equals("-")){
                        options = getSearchTerms2(myMOA);
                        getFillView2(options.get(0));
                    }
                    else{
                        Toast.makeText(drugSpecifics.this, "Invalid search", Toast.LENGTH_LONG).show();
                    }

                }
                else{
                    Toast.makeText(drugSpecifics.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void fillRest(){
        if(getIntent().hasExtra("Drug Details")){
            if(getIntent().getStringArrayExtra("Drug Details") != null){
                String[] tokens = getIntent().getStringArrayExtra("Drug Details");
                type.setText("Molecule Type: " + tokens[1].toString());
                indication.setText("Indication: " + tokens[2].toString());
                approval.setText("Approval: " + tokens[6]);
                target.setText("Target(s): " +tokens[3].toString());
                if (tokens[4] != null || tokens[4] != ""){
                    target.append(", " + tokens[4].toString());
                }
                moa.setText("Mechanism of Action: " + tokens[5].toString());
                if(tokens[5].equals("-") || tokens[5].equalsIgnoreCase("No name")){
                    search2.setEnabled(false);
                }
                myMOA = tokens[5];
                desc.setText(tokens[7]);
                rawlink = tokens[8];

            }
        }
        else{
            Toast.makeText(drugSpecifics.this, "No data available",Toast.LENGTH_LONG).show();
        }

    }


    public void openSearchbyName(){
        Intent intent = new Intent(this, searchbyname.class);
        intent.putExtra("Drug Name", myName.toString());
        startActivity(intent);
    }
    public void openSearchbyMOA(){
        Intent intent = new Intent(this, searchbymoa.class);
        intent.putExtra("MOA name", myMOA.toString());
        startActivity(intent);
    }
    public void connect1(View view){
        Intent intent =  new Intent(Intent.ACTION_VIEW, Uri.parse(rawlink));
        startActivity(intent);

    }

    public void getFillView(String term){
        StringBuilder drug_all_details = new StringBuilder();
        drug_all_details.append(name.getText().toString());
        Log.d("DrugSpecific", "All content" + drug_all_details.toString());
        Object[] arrOthers = options.toArray();
        fillView2 f1 = new fillView2(drugSpecifics.this, 10, term, "All",searchbyname.class, "Drug",Arrays.copyOf(arrOthers, arrOthers.length, String[].class));
//
        f1.execute();

    }
    public void getFillView2(String term){
        StringBuilder drug_all_details = new StringBuilder();
        drug_all_details.append(myMOA);
        Log.d("DrugSpecific", "All content" + drug_all_details.toString());
        Object[] arrOthers = options.toArray();
        fillView2 f1 = new fillView2(drugSpecifics.this, 10, term, "All",searchbymoa.class, "Drug", Arrays.copyOf(arrOthers, arrOthers.length, String[].class));
//
        f1.execute();


    }


    public static boolean isNetworkAvailable(Context context) {
        if(context == null)  return false;


        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager != null) {


            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        return true;
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        return true;
                    }  else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)){
                        return true;
                    }
                }
            }

            else {

                try {
                    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
                    if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                        Log.i("update_statut", "Network is available : true");
                        return true;
                    }
                } catch (Exception e) {
                    Log.i("update_statut", "" + e.getMessage());
                }
            }
        }
        Log.i("update_statut","Network is available : FALSE ");
        return false;
    }

    public List<String> getSearchTerms2(String name){
        List<String> terms = new ArrayList<>();
        if(name.contains(",")){
            String[] tokens = name.split(",");
            for(int i = 0; i < tokens.length;i++){
                if(tokens[i].contains("(") && tokens[i].contains(")")){
                    String term2 = tokens[i].substring(name.indexOf("(")+1,name.indexOf(")"));
                    String term1 = tokens[i].substring(0,name.indexOf("("));
                    terms.add(term1);
                    terms.add(term2);
                }
                else{
                    terms.add(tokens[i]);
                    String[] spaceBreaks = tokens[i].split(" ");
                    if(spaceBreaks.length > 1){
                        terms.add(spaceBreaks[spaceBreaks.length-1]);
                    }

                }

            }
        }
        else if(name.contains("(") && name.contains(")")){
            terms.add(name.substring(0,name.indexOf("(")));
            String[] spaceBreaks = name.substring(0,name.indexOf("(")).split(" ");
            if(spaceBreaks.length > 1){
                terms.add(spaceBreaks[spaceBreaks.length-1]);
            }
            String[] tokens = name.substring(name.indexOf("(")+1,name.indexOf(")")).split(",");
            for (int i = 0; i < tokens.length; i++){
                terms.add(tokens[i]);
            }

        }
        else{
            terms.add(name);
            String[] spaceBreaks = name.split(" ");
            if(spaceBreaks.length > 1){
                terms.add(spaceBreaks[spaceBreaks.length-1]);
            }


        }

        return terms;
    }

    public List<String> getSearchTerms(String name){
        List<String> terms = new ArrayList<>();
        if(name.contains("(") && name.contains(")")){
            terms.add(name.substring(0,name.indexOf("(")));
            String[] tokens = name.substring(name.indexOf("(")+1,name.indexOf(")")).split(",");
            for (int i = 0; i < tokens.length; i++){
                terms.add(tokens[i]);
            }

        }
        else{
            terms.add(name);
        }

        return terms;

    }

}
